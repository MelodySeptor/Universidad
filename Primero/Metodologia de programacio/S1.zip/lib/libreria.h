#pragma once

#include "keyboard.h"
#include "mouse.h"
#include "sprites.h"
#include "video.h"
#include "sound.h"
#include <cstring>