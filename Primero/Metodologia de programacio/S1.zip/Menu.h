
#include <stdio.h>      /* printf */
#include <stdlib.h>     /* system */

void menuPrincipal();
void menuNivellDificultat();
